const campoValor = document.querySelector(".valor");
$(campoValor).mask('000.000.000.000.000,00', {reverse: true});