const tel = document.getElementsByClassName('telefones');
$(tel).mask('(00) 00000-0000');